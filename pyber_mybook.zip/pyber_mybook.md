

```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sb

```


```python
csvfile1 = 'raw_data/city_data.csv'
csvfile2 = 'raw_data/ride_data.csv'
city_data_df = pd.read_csv(csvfile1)

ride_data = pd.read_csv(csvfile2)
pyber_data = pd.merge(ride_data, city_data, on="city")
pyber_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>city</th>
      <th>date</th>
      <th>fare</th>
      <th>ride_id</th>
      <th>driver_count</th>
      <th>type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lake Jonathanshire</td>
      <td>2018-01-14 10:14:22</td>
      <td>13.83</td>
      <td>5739410935873</td>
      <td>5</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Lake Jonathanshire</td>
      <td>2018-04-07 20:51:11</td>
      <td>31.25</td>
      <td>4441251834598</td>
      <td>5</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Lake Jonathanshire</td>
      <td>2018-03-09 23:45:55</td>
      <td>19.89</td>
      <td>2389495660448</td>
      <td>5</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Lake Jonathanshire</td>
      <td>2018-04-07 18:09:21</td>
      <td>24.28</td>
      <td>7796805191168</td>
      <td>5</td>
      <td>Urban</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Lake Jonathanshire</td>
      <td>2018-01-02 14:14:50</td>
      <td>13.89</td>
      <td>424254840012</td>
      <td>5</td>
      <td>Urban</td>
    </tr>
  </tbody>
</table>
</div>




```python
total_rides = pyber_data.groupby('city')['ride_id'].count()
driver_count = pyber_data.groupby('city')['driver_count'].mean()
average_fare = pyber_data.groupby('city')['fare'].mean()
total_fare = pyber_data.groupby('city')['fare'].sum()
city_type = pyber_data.groupby('city')['type'].unique()
```


```python
newdf = pd.DataFrame({'total rides': total_rides, 'driver count': driver_count, 'average fare': average_fare, 'total fare': total_fare, 'city type': city_type})
newdf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total rides</th>
      <th>driver count</th>
      <th>average fare</th>
      <th>total fare</th>
      <th>city type</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Amandaburgh</th>
      <td>18</td>
      <td>12</td>
      <td>24.641667</td>
      <td>443.55</td>
      <td>[Urban]</td>
    </tr>
    <tr>
      <th>Barajasview</th>
      <td>22</td>
      <td>26</td>
      <td>25.332273</td>
      <td>557.31</td>
      <td>[Urban]</td>
    </tr>
    <tr>
      <th>Barronchester</th>
      <td>16</td>
      <td>11</td>
      <td>36.422500</td>
      <td>582.76</td>
      <td>[Suburban]</td>
    </tr>
    <tr>
      <th>Bethanyland</th>
      <td>18</td>
      <td>22</td>
      <td>32.956111</td>
      <td>593.21</td>
      <td>[Suburban]</td>
    </tr>
    <tr>
      <th>Bradshawfurt</th>
      <td>10</td>
      <td>7</td>
      <td>40.064000</td>
      <td>400.64</td>
      <td>[Rural]</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Urban
urban  =  newdf.loc[newdf["city type"]== "Urban"]
#suburban
suburban = newdf.loc[newdf["city type"]== "Suburban"]
#rural
rural = newdf.loc[newdf["city type"]== "Rural"]

```


```python
plt.scatter(urban['total rides'], urban['average fare'], s= urban['driver count']*5, color = "gold", edgecolors="black", label= 'Urban')
plt.scatter(suburban['total rides'], suburban['average fare'], s= suburban['driver count']*5, color = "lightskyblue", edgecolors="black", label= 'Suburban')
plt.scatter(rural['total rides'], rural['average fare'], s= rural['driver count']*5, color = "coral", edgecolors="black", label= 'Rural')
plt.legend()
plt.xlabel('Total rides per city')
plt.ylabel('average fare per city')
plt.title('Total Rides vs Average Fare by City')
plt.grid()
```


![png](output_5_0.png)


1) Fares are higher in rural areas than they are elsewhere and urban areas have the lowest fares. this can most likely be attributed to the distance travelled since things are closer together in larger cities. 
2) Urban areas have the highest amount of drivers, most likely due to the demand for rides being higher due to population which is also reflected in the chart.
3) Some urban and suburban cities have given more rides than others despite having fewer drivers available. there seems to be no direct correlation between the two.
4) based on pie charts city type seems to be the main determinant in driver count, average fair, and number of rides, as the data for each pie chart is very similar. 


```python
farepie = pyber_data.groupby(['type'])['fare'].sum()
labels = pie.index
colors = ["gold", "lightskyblue", "lightcoral"]
explode = (0,0, 0.1)
plt.pie(farepie, explode= explode, colors= colors, labels= labels, autopct= "%1.2f%%", shadow = True)
plt.axis("equal")
plt.legend()
plt.title('% of Total Fares by City Type')
```




    Text(0.5,1,'% of Total Fares by City Type')




![png](output_7_1.png)



```python
driverpie = pyber_data.groupby(['type'])['driver_count'].mean()

plt.pie(driverpie, explode= explode, colors= colors, labels= labels, autopct= "%1.2f%%", shadow = True)
plt.axis("equal")
plt.legend()
plt.title('% of Total Drivers by City Type')
```




    Text(0.5,1,'% of Total Drivers by City Type')




![png](output_8_1.png)



```python
ridepie = pyber_data.groupby(['type'])['ride_id'].count()
labels = pie.index
colors = ["gold", "lightskyblue", "lightcoral"]
explode = (0,0, 0.1)
plt.pie(ridepie, explode= explode, colors= colors, labels= labels, autopct= "%1.2f%%", shadow = True)
plt.axis("equal")
plt.legend()
plt.title('% of Total Rides by City Type')
```




    Text(0.5,1,'% of Total Rides by City Type')




![png](output_9_1.png)

